﻿namespace P02_FootballBetting;

public class StartUp
{
    static void Main(string[] args)
    {
        
    }
}