﻿namespace _02P_FootBallBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnnectionString = @"Server=(LocalDB)\MSSQLLocalDB
           ;Database = Bet388; 
          Trusted_Connection = True;";


    }
}